import 'package:flutter/material.dart';

class CoolTable extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return null;
  }
}

class CoolTableState extends State<CoolTable>{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return null;
  }
}

class CoolColumnInfo{
  final double flex;
  final double width;
  final double minWidth;
  final double maxWidth;

  const CoolColumnInfo({this.flex, this.width, this.minWidth, this.maxWidth});
}